function change_text() {
    document.getElementById("mambo").innerHTML = "MAMBO!";
}